export default {
  logoUrl: "https://dummyimage.com/256x256/0c1422/43d7ff.png&text=CF"
};
