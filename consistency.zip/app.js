(() => {
  const stage = document.querySelector('#sceneStage');
  const powerToggle = document.querySelector('#powerToggle');
  if (!stage || !powerToggle) return;

  const state = {
    power: false,
    running: false,
    connected: new Set(['l1', 'stop', 'start', 'aux', 'coil'])
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const allConnectionsReady = () => state.connected.size === 5;
  const connectedLabel = () => `${state.connected.size} / 5 연결`;

  function create3DSimulation() {
    const canvas = $('#simCanvas');
    const dialog = $('#simDialog');
    if (!canvas || !dialog) return null;
    const ctx = canvas.getContext('2d');
    const camera = { yaw: -0.42, pitch: -0.18, zoom: 1 };
    let width = 0;
    let height = 0;
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let time = 0;
    let snapshot = { power: false, running: false, connected: 0 };
    const colors = { cyan: '#43d7ff', orange: '#ff9c58', red: '#f06568', yellow: '#ffd45d', purple: '#b08aff', green: '#68e3ac', steel: '#718c96', dark: '#152b38', plastic: '#25465b' };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      width = rect.width; height = rect.height;
      canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const rotate = (point) => {
      const cy = Math.cos(camera.yaw), sy = Math.sin(camera.yaw);
      const x = point.x * cy - point.z * sy;
      const z = point.x * sy + point.z * cy;
      const cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch);
      return { x, y: point.y * cp - z * sp, z: point.y * sp + z * cp };
    };
    const project = (point) => {
      const p = rotate(point);
      const scale = Math.min(width, height) * .22 * camera.zoom;
      const depth = 1 / (1 + p.z * .08);
      return { x: width / 2 + (p.x - p.z * .42) * scale * depth, y: height / 2 + (p.y + p.z * .24) * scale * depth, z: p.z };
    };
    const cube = (center, size, color, label) => {
      const [w, h, d] = size;
      const verts = [[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]].map(([x,y,z]) => project({ x: center.x + x*w/2, y: center.y + y*h/2, z: center.z + z*d/2 }));
      const faces = [[0,1,2,3],[4,7,6,5],[0,4,5,1],[3,2,6,7],[1,5,6,2],[0,3,7,4]].map((face, index) => ({ face, index, depth: face.reduce((sum, i) => sum + verts[i].z, 0) / 4 })).sort((a,b) => a.depth - b.depth);
      faces.forEach(({ face, index }) => { const shade = [color, '#9db4bb', '#304e5d', '#507180', '#1b3444', '#416171'][index]; ctx.beginPath(); face.forEach((i, n) => n ? ctx.lineTo(verts[i].x, verts[i].y) : ctx.moveTo(verts[i].x, verts[i].y)); ctx.closePath(); ctx.fillStyle = shade; ctx.globalAlpha = index === 0 ? .9 : .68; ctx.fill(); ctx.strokeStyle = 'rgba(182, 222, 226, .34)'; ctx.lineWidth = 1; ctx.stroke(); });
      ctx.globalAlpha = 1;
      if (label) { const p = project({ x: center.x, y: center.y - h / 2 - .09, z: center.z - d / 2 }); ctx.fillStyle = 'rgba(217, 242, 239, .8)'; ctx.font = '10px Arial Narrow, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(label, p.x, p.y); }
    };
    const line = (points, color, live, offset = 0) => { const projected = points.map(project); ctx.beginPath(); projected.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.strokeStyle = live ? color : 'rgba(143, 184, 194, .28)'; ctx.lineWidth = live ? 3 : 2; ctx.shadowColor = live ? color : 'transparent'; ctx.shadowBlur = live ? 10 : 0; ctx.stroke(); ctx.shadowBlur = 0; if (live) { const point = projected[Math.floor((time * .08 + offset) % projected.length)]; ctx.beginPath(); ctx.arc(point.x, point.y, 4, 0, Math.PI * 2); ctx.fillStyle = '#f4ffff'; ctx.shadowColor = color; ctx.shadowBlur = 12; ctx.fill(); ctx.shadowBlur = 0; } };
    const drawMotor = (center, live) => { const c = project(center); const radius = Math.min(width, height) * .115 * camera.zoom; ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(live ? time * .04 : 0); ctx.strokeStyle = live ? colors.green : 'rgba(157, 194, 196, .65)'; ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(0, 0, radius * .48, 0, Math.PI * 2); ctx.stroke(); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; ctx.beginPath(); ctx.moveTo(Math.cos(a) * radius * .14, Math.sin(a) * radius * .14); ctx.lineTo(Math.cos(a + .28) * radius * .46, Math.sin(a + .28) * radius * .46); ctx.strokeStyle = live ? colors.orange : '#55727d'; ctx.lineWidth = 5; ctx.stroke(); } ctx.fillStyle = '#aec2be'; ctx.beginPath(); ctx.arc(0, 0, radius * .13, 0, Math.PI * 2); ctx.fill(); ctx.restore(); };
    const draw = () => { time += 1; if (!width) resize(); const live = snapshot.power && snapshot.running && snapshot.connected === 5; ctx.clearRect(0, 0, width, height); ctx.fillStyle = 'rgba(8, 19, 29, .55)'; ctx.fillRect(0, 0, width, height); ctx.strokeStyle = 'rgba(111, 175, 191, .16)'; ctx.lineWidth = 1; for (let i = -8; i <= 8; i++) { line([{x: i, y: 1.45, z: -4}, {x: i, y: 1.45, z: 4}], 'rgba(111,175,191,.13)', false); line([{x: -4, y: 1.45, z: i}, {x: 4, y: 1.45, z: i}], 'rgba(111,175,191,.13)', false); } cube({x: -.8, y: .15, z: 0}, [1.55, 2.25, .72], colors.steel, 'CONTROL PANEL / KM1'); cube({x: -.8, y: -.08, z: -.42}, [1.16, .55, .03], colors.dark, live ? 'COIL ENERGIZED' : 'STANDBY'); cube({x: -.8, y: -.72, z: -.43}, [.23, .26, .05], live ? colors.green : colors.red, 'SB0'); cube({x: -.38, y: -.72, z: -.43}, [.23, .26, .05], colors.yellow, 'SB1'); cube({x: .96, y: .34, z: 0}, [1.3, .85, 1.08], colors.plastic, 'M1 / MOTOR'); drawMotor({x: 1.43, y: .34, z: -.56}, live); line([{x:-1.55,y:-.64,z:-.48},{x:-1.05,y:-.64,z:-.48},{x:-.8,y:-.4,z:-.48},{x:-.38,y:-.72,z:-.48}], colors.red, live, 0); line([{x:-.38,y:-.72,z:-.48},{x:-.12,y:-.72,z:-.48},{x:-.38,y:-.22,z:-.48}], colors.yellow, live, 1); line([{x:-.38,y:-.22,z:-.48},{x:.15,y:-.22,z:-.48},{x:.45,y:.42,z:-.48},{x:1.02,y:.42,z:-.48}], colors.purple, live, 2); line([{x:1.02,y:.42,z:-.48},{x:1.4,y:.42,z:-.48},{x:1.4,y:.72,z:-.48}], colors.green, live, 3); ctx.fillStyle = 'rgba(207, 235, 231, .6)'; ctx.font = '10px Arial Narrow, sans-serif'; ctx.textAlign = 'left'; ctx.fillText('DRAG / ORBIT', 18, height - 19); ctx.fillText('ZOOM ' + Math.round(camera.zoom * 100) + '%', width - 82, height - 19); requestAnimationFrame(draw); };
    const begin = (event) => { dragging = true; lastX = event.clientX; lastY = event.clientY; canvas.setPointerCapture?.(event.pointerId); };
    const move = (event) => { if (!dragging) return; camera.yaw += (event.clientX - lastX) * .008; camera.pitch = Math.max(-.75, Math.min(.65, camera.pitch + (event.clientY - lastY) * .006)); lastX = event.clientX; lastY = event.clientY; };
    const end = () => { dragging = false; };
    canvas.addEventListener('pointerdown', begin); canvas.addEventListener('pointermove', move); canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end); canvas.addEventListener('wheel', (event) => { event.preventDefault(); camera.zoom = Math.max(.72, Math.min(1.55, camera.zoom - event.deltaY * .001)); }, { passive: false });
    window.addEventListener('resize', resize);
    return { update: (next) => { snapshot = next; }, start: () => { resize(); requestAnimationFrame(draw); }, resize, reset: () => { camera.yaw = -.42; camera.pitch = -.18; camera.zoom = 1; resize(); } };
  }

  const sim = create3DSimulation();
  sim?.start();

  function showToast(message) {
    const toast = $('#toast');
    const text = $('#toastText');
    if (!toast || !text) return;
    text.textContent = message;
    toast.classList.add('is-visible');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove('is-visible'), 2600);
  }

  function setSequence(step) {
    $$('.sequence-step').forEach((item, index) => item.classList.toggle('is-current', index === step));
  }

  function setConnectionUi() {
    $$('.connection-row').forEach((row) => {
      const key = row.dataset.connection;
      const connected = state.connected.has(key);
      row.classList.toggle('is-connected', connected);
      const button = row.querySelector('.connect-btn');
      if (button) button.textContent = connected ? '연결됨' : '단선';
    });
    const count = $('#connectionCount');
    if (count) count.textContent = connectedLabel();
  }

  function updatePowerUi() {
    const ready = allConnectionsReady();
    const live = state.power && ready && state.running;
    const on = state.power && ready;
    stage.classList.toggle('is-live', live);
    powerToggle.classList.toggle('is-active', state.power);
    powerToggle.innerHTML = state.power ? '<span class="button-lamp"></span> 전원 차단' : '<span class="button-lamp"></span> 전원 인가';

    const status = $('#powerStatus');
    const monitor = $('#monitorDot');
    const statusText = status?.querySelector('span');
    status?.classList.toggle('is-live', on);
    status?.classList.toggle('is-warning', state.power && !ready);
    monitor?.classList.toggle('is-live', live);
    if (statusText) statusText.textContent = state.power ? (ready ? 'ON / ARMED' : 'ON / CHECK') : 'OFF / READY';

    const current = live ? '0.42' : '0.00';
    const currentValue = $('#currentValue');
    const meterValue = $('#meterValue');
    const meterState = $('#meterState');
    if (currentValue) currentValue.textContent = current;
    if (meterValue) meterValue.textContent = live ? '0.42' : '0.0';
    if (meterState) meterState.textContent = live ? 'COIL ENERGIZED' : (state.power && !ready ? 'WIRING ERROR' : 'STANDBY');
    const needle = $('#meterNeedle');
    if (needle) needle.style.transform = live ? 'rotate(29deg)' : 'rotate(-58deg)';
    const progress = $('#currentProgress');
    if (progress) progress.style.width = live ? '72%' : (state.power ? '16%' : '0%');
    const loopState = $('#loopState');
    if (loopState) loopState.textContent = live ? 'CLOSED / HOLD' : (state.power && !ready ? 'OPEN / FAULT' : 'OPEN');
    const hint = $('#currentHint');
    if (hint) hint.textContent = live ? '전류가 L1에서 SB0, SB1, KM1을 지나 귀환 중입니다.' : (state.power && !ready ? '단선된 단자를 확인한 뒤 전원을 다시 인가하세요.' : state.power ? '기동 버튼을 눌러 KM1 코일을 여자하세요.' : '전원 버튼을 눌러 제어 전원을 투입하세요.');
    const message = $('#currentMessage');
    if (message) message.textContent = live ? '전류 흐름 활성 · KM1 자기유지 중' : (state.power && !ready ? '회로 단선 · 연결 상태를 확인하세요' : state.power ? '전원 인가 완료 · 기동 신호 대기' : '전원 인가 전 · 회로를 확인하세요');
    const resultTitle = $('#resultTitle');
    const resultText = $('#resultText');
    if (resultTitle) resultTitle.textContent = live ? '자기유지 동작 중' : (state.power && !ready ? '연결 오류 감지' : state.power ? '기동 대기' : '전원 투입 대기');
    if (resultText) resultText.textContent = live ? 'KM1 보조접점 13–14가 기동 회로를 대신하고 있습니다.' : (state.power && !ready ? '모든 배선이 연결되어야 코일을 여자할 수 있습니다.' : state.power ? 'SB1 기동을 눌러 자기유지 회로를 확인하세요.' : '모든 단자를 연결하고 전원을 인가하세요.');
    const card = document.querySelector('.current-card');
    card?.classList.toggle('is-live', live);
    setSequence(live ? 2 : state.power ? 1 : 0);
    sim?.update({ power: state.power, running: state.running, connected: state.connected.size });
    const simState = $('#simStateLabel');
    const simModelState = $('#simModelState');
    const simCurrent = $('#simCurrentReadout');
    if (simState) simState.textContent = live ? 'POWER ON / CURRENT FLOW' : state.power ? 'POWER ON / ARMED' : 'POWER OFF / READY';
    if (simModelState) simModelState.textContent = live ? 'COIL ENERGIZED / HOLD' : state.power ? 'ARMED / START READY' : 'STANDBY';
    if (simCurrent) simCurrent.textContent = `${live ? '0.42' : '0.00'} A`;
    const simPower = $('#simPower');
    if (simPower) simPower.textContent = state.power ? '전원 차단' : '전원 인가';
  }

  function togglePower() {
    if (!state.power) {
      state.power = true;
      state.running = false;
      if (!allConnectionsReady()) showToast('전원은 인가되었지만 단선된 배선이 있습니다.');
      else showToast('제어 전원 인가 · 기동 버튼을 눌러 회로를 여자하세요.');
    } else {
      state.power = false;
      state.running = false;
      showToast('전원 차단 · 회로가 안전 상태로 돌아왔습니다.');
    }
    updatePowerUi();
  }

  function startMotor() {
    if (!state.power) {
      showToast('먼저 오른쪽 상단의 전원 인가를 눌러주세요.');
      return;
    }
    if (!allConnectionsReady()) {
      showToast('기동 불가 · 단자 연결 상태를 확인하세요.');
      return;
    }
    state.running = true;
    showToast('SB1 기동 · KM1 보조접점이 자기유지 중입니다.');
    updatePowerUi();
  }

  function stopMotor() {
    state.running = false;
    if (state.power) showToast('SB0 정지 · NC 접점이 열리고 전류가 차단됩니다.');
    else showToast('정지 상태입니다. 전원을 인가하면 다시 실습할 수 있습니다.');
    updatePowerUi();
  }

  function resetLab() {
    state.power = false;
    state.running = false;
    state.connected = new Set(['l1', 'stop', 'start', 'aux', 'coil']);
    setConnectionUi();
    updatePowerUi();
    showToast('실습 회로가 초기 상태로 리셋되었습니다.');
  }

  $$('.connection-row').forEach((row) => {
    row.addEventListener('click', () => {
      const key = row.dataset.connection;
      if (state.connected.has(key)) state.connected.delete(key);
      else state.connected.add(key);
      if (!allConnectionsReady()) state.running = false;
      setConnectionUi();
      updatePowerUi();
      showToast(state.connected.has(key) ? `${key.toUpperCase()} 배선 연결됨` : `${key.toUpperCase()} 배선 단선됨`);
    });
  });

  powerToggle.addEventListener('click', togglePower);
  $('#startAction')?.addEventListener('click', startMotor);
  $('#stopAction')?.addEventListener('click', stopMotor);
  $('#resetLab')?.addEventListener('click', resetLab);
  $('#open3d')?.addEventListener('click', () => { const dialog = $('#simDialog'); if (dialog?.showModal) { dialog.showModal(); sim?.resize(); } });
  $('#close3d')?.addEventListener('click', () => $('#simDialog')?.close());
  $('#simDialog')?.addEventListener('click', (event) => { if (event.target === event.currentTarget) event.currentTarget.close(); });
  $('#simResetView')?.addEventListener('click', () => sim?.reset());
  $('#simPower')?.addEventListener('click', togglePower);
  $('#simStart')?.addEventListener('click', startMotor);
  $('#simStop')?.addEventListener('click', stopMotor);

  $('#interlockDoor')?.addEventListener('click', (event) => {
    event.currentTarget.classList.toggle('is-selected');
    showToast('인터록 실습실 · 안전 조건과 보호 접점을 확인하는 공간입니다.');
  });
  $('#autoDoor')?.addEventListener('click', (event) => {
    event.currentTarget.classList.toggle('is-selected');
    showToast('자동기동 실습실 · 순차기동과 타이머 회로를 실습하는 공간입니다.');
  });

  setConnectionUi();
  updatePowerUi();
})();
